chrome.runtime.onInstalled.addListener(() => {
  console.log('GigaDesk Chrome Extension installed');
});

// Handle messages from popup
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.type === 'START_RECORDING') {
    // Handle recording start
    sendResponse({ status: 'success' });
  } else if (request.type === 'STOP_RECORDING') {
    // Handle recording stop
    sendResponse({ status: 'success' });
  }
  return true;
});