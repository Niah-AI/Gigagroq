import { authService } from './services/authService';
import { audioService } from './services/audioService';
import { transcriptionService } from './services/transcriptionService';

class PopupUI {
  constructor() {
    this.loginView = document.getElementById('login-view');
    this.mainView = document.getElementById('main-view');
    this.loginForm = document.getElementById('login-form');
    this.status = document.getElementById('status');
    this.transcription = document.getElementById('transcription');
    
    this.startButton = document.getElementById('startRecording');
    this.stopButton = document.getElementById('stopRecording');
    this.summarizeButton = document.getElementById('summarize');
    this.copyButton = document.getElementById('copy');
    this.logoutButton = document.getElementById('logout');

    this.initializeEventListeners();
    this.checkAuthAndInitialize();
  }

  async checkAuthAndInitialize() {
    try {
      const isAuthenticated = await authService.checkAuth();
      if (isAuthenticated) {
        this.showMainView();
      } else {
        this.showLoginView();
      }
    } catch (error) {
      this.showError('Authentication check failed');
    }
  }

  initializeEventListeners() {
    this.loginForm.addEventListener('submit', this.handleLogin.bind(this));
    this.startButton.addEventListener('click', this.handleStartRecording.bind(this));
    this.stopButton.addEventListener('click', this.handleStopRecording.bind(this));
    this.summarizeButton.addEventListener('click', this.handleSummarize.bind(this));
    this.copyButton.addEventListener('click', this.handleCopy.bind(this));
    this.logoutButton.addEventListener('click', this.handleLogout.bind(this));
  }

  async handleLogin(event) {
    event.preventDefault();
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;

    try {
      await authService.login({ email, password });
      this.showMainView();
    } catch (error) {
      this.showError('Login failed: ' + error.message);
    }
  }

  async handleStartRecording() {
    try {
      await audioService.startRecording();
      this.updateUI(true);
      this.status.textContent = 'Recording...';
    } catch (error) {
      this.showError('Recording failed: ' + error.message);
    }
  }

  async handleStopRecording() {
    try {
      const audioBlob = await audioService.stopRecording();
      this.status.textContent = 'Processing audio...';
      this.updateUI(false);
      
      const transcription = await transcriptionService.transcribe(audioBlob);
      this.transcription.textContent = transcription;
      this.status.textContent = 'Transcription complete';
      this.summarizeButton.disabled = false;
      this.copyButton.disabled = false;
    } catch (error) {
      this.showError('Processing failed: ' + error.message);
    }
  }

  async handleSummarize() {
    try {
      this.status.textContent = 'Generating summary...';
      const summary = await transcriptionService.summarize(this.transcription.textContent);
      this.transcription.textContent = summary;
      this.status.textContent = 'Summary generated';
    } catch (error) {
      this.showError('Summarization failed: ' + error.message);
    }
  }

  async handleCopy() {
    try {
      await navigator.clipboard.writeText(this.transcription.textContent);
      this.status.textContent = 'Copied to clipboard';
      setTimeout(() => {
        this.status.textContent = 'Ready';
      }, 2000);
    } catch (error) {
      this.showError('Copy failed: ' + error.message);
    }
  }

  async handleLogout() {
    try {
      await authService.logout();
      this.showLoginView();
    } catch (error) {
      this.showError('Logout failed: ' + error.message);
    }
  }

  updateUI(isRecording) {
    this.startButton.disabled = isRecording;
    this.stopButton.disabled = !isRecording;
    this.summarizeButton.disabled = true;
    this.copyButton.disabled = true;
  }

  showError(message) {
    this.status.textContent = message;
    console.error(message);
  }

  showLoginView() {
    this.loginView.classList.remove('hidden');
    this.mainView.classList.add('hidden');
  }

  showMainView() {
    this.loginView.classList.add('hidden');
    this.mainView.classList.remove('hidden');
  }
}

// Initialize the UI when the popup loads
document.addEventListener('DOMContentLoaded', () => {
  new PopupUI();
});