export const API_CONFIG = {
  GROQ_API_KEY: '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',
  GROQ_API_URL: 'https://api.groq.com/v1/chat/completions',
  MODEL: 'mixtral-8x7b-32768'
};