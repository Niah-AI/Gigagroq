import { API_CONFIG } from '../config';

class TranscriptionService {
  async transcribe(audioBlob) {
    try {
      // Convert audio blob to base64
      const base64Audio = await this.blobToBase64(audioBlob);
      
      const response = await fetch(API_CONFIG.GROQ_API_URL, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${API_CONFIG.GROQ_API_KEY}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          model: API_CONFIG.MODEL,
          messages: [
            {
              role: 'system',
              content: 'You are a highly accurate transcription assistant. Convert the audio to text, maintaining proper punctuation and formatting.'
            },
            {
              role: 'user',
              content: `Please transcribe this audio: ${base64Audio}`
            }
          ],
          temperature: 0.1,
          max_tokens: 32000
        })
      });

      if (!response.ok) {
        throw new Error('Transcription failed');
      }

      const data = await response.json();
      return data.choices[0].message.content;
    } catch (error) {
      throw new Error(`Transcription failed: ${error.message}`);
    }
  }

  async summarize(text) {
    try {
      const response = await fetch(API_CONFIG.GROQ_API_URL, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${API_CONFIG.GROQ_API_KEY}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          model: API_CONFIG.MODEL,
          messages: [
            {
              role: 'system',
              content: 'You are a highly efficient summarization assistant. Create clear, concise summaries while maintaining key information.'
            },
            {
              role: 'user',
              content: `Please provide a concise summary of this text: ${text}`
            }
          ],
          temperature: 0.3,
          max_tokens: 1000
        })
      });

      if (!response.ok) {
        throw new Error('Summarization failed');
      }

      const data = await response.json();
      return data.choices[0].message.content;
    } catch (error) {
      throw new Error(`Summarization failed: ${error.message}`);
    }
  }

  private blobToBase64(blob) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onloadend = () => {
        const base64String = reader.result
          .replace('data:', '')
          .replace(/^.+,/, '');
        resolve(base64String);
      };
      reader.onerror = reject;
      reader.readAsDataURL(blob);
    });
  }
}

export const transcriptionService = new TranscriptionService();